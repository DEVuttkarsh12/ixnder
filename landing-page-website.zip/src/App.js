import './App.css';
import Navbar from './Components/Navbar/Navbar';
import LandingPage from './Components/Landing-Page/LandingPage';
import Latest from './Components/Latest/Latest';
import ExpandingServices from './Components/ExpandingServices/ExpandingServices';
import LogoTab from './Components/Logobar/LogoTab';
import Solutions from './Components/Solutions/Solutions';
import TheSecondPage from './Components/TheSecondPage/TheSecondPage';
import CoFounder from './Components/CoFounder/CoFounder';
import BeIncredible from './Components/BeIncredible/BeIncredible';
function App() {
  return (
    <div className="App">
      <Navbar />
      <LandingPage />
     <LogoTab />
      <TheSecondPage />
      <Latest />
      <ExpandingServices />
      <Solutions />
      <CoFounder />
      <BeIncredible />
    </div>
  );
}

export default App;
