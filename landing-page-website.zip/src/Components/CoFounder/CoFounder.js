import React from 'react'
import './CoFounder.css'
import Image1 from './img1.png'

const CoFounder = () => {
  return (
    <div className='CoFounderContainer'>
        <div className='InnerCoFounder'>
            <img 
            src={Image1}
            className='mnbb'
            />
            <div className='WrittenContent'>
            <h5 className='marr'>Marie Poirot, Co-Founder Art-gAL</h5>
          <h3 className='anf'>
            "Hello World how are you<br></br>
             and also 
            what are you doing hello<br></br>
             world how
            are you and also what are<br></br>
             you doing 
            hello world how are you and<br></br>
             also what are you doing"
          </h3>
            </div>
            
        </div>
    </div>
  )
}

export default CoFounder