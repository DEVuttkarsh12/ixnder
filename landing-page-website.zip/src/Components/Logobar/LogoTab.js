import React from 'react'

import './Logobar.css'

import Image2 from './adidas.png'
import Image3 from './nike.png'
import Image4 from './harleydavidson.png'
import Image5 from './microsoft.png'



const LogoTab = () => {
  return (
    <div className='logobarcontainer'>
    <div className='TheSecondDiv'>
  <img 
  src={Image2}
  className='image2'
  />
  <img 
  src={Image2}
  className='image3'
  />
  <img />
  <img 
  src={Image2}
  className='image4'
  />
  <img 
  src={Image2}
  className='image5'
  />
</div> 
</div>
  )
}

export default LogoTab