import React from 'react'
import './TheSecondPage.css'
import Image1 from './imgimg1.jpg'
import Image2 from './imgimg2.jpg'
import Image3 from './imgimg3.jpg'
import Image4 from './imgimg4.jpg'
import Image5 from './imgimg5.jpg'



const TheSecondPage = () => {
  return (
    
<>
<a href='#' className='viewview1'>Discover All Catagories</a>
<div>
  <h1 className='yup'>Featured Art Catagories</h1>
</div>
<div className='SecondDivContainer'>

<div className='cards'>
<h1 className='innercontent'>
      
      pottery</h1>
      <h1 className='innerinnercontent'>
        Family Vases
      </h1>

</div>
<div className='cards1'>

    <h1 className='innercontent'>
      
    Oil Painting</h1>
    <h1 className='innerinnercontent'>
      Camel Potrait
    </h1>
</div>
<div className='cards2'>

    <h1 className='innercontent'>
    Abstract Painting</h1>
    <h1 className='innerinnercontent'>
      Euforia
    </h1>
</div>
<div className='cards3'>

    <h1 className='innercontent'>
    Object Design</h1>
    <h1 className='innerinnercontent'>
     Classic Watch
    </h1>
</div>
<div className='cards4'>

    <h1 className='innercontent'>
    Sculpture</h1>
    <h1 className='innerinnercontent'>
     White Painting
    </h1>
</div>
</div></>
  )
}

export default TheSecondPage