import React from 'react'
import './LandingPage.css'
import Image1 from './img1.png'


const LandingPage = () => {


        

  return (
    <div className='maincontainer'>
      <div className='text'>
    <div className='innerinnertitle'>
    <h1 className='innertitle'>Search The Work Of<br></br>
       The Best Artists</h1>
    </div>
    <div className='SearchBar'>
      <input className='SearchSearchBar' type='search' placeholder='Search for Artists , Work Name , Or Catagory'></input><button className='buttonbutton'>Search</button>
    </div>
    
<div className='texttext'>
  <button className='poptext'>Oil Painting</button>
  <button className='poptext'>Abstract Art</button>
  <button className='poptext'>Sculpture</button>
  <button className='poptext'>Art Deco</button>
  <button className='poptext'>Pop Art</button>
</div>


<img
  className='Image1'
  src={Image1}
   />
      </div>
    
    </div>
  )
}

export default LandingPage