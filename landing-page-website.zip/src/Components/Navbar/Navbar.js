import React from 'react'
import './Navbar.css'
const Navbar = () => {
  return (
    <div className='Navbar'>
      <div className='Title divcenternavbar'>
    <p className='logo'>Xinder</p>
      </div>
      <div className='middleone divcenternavbar'></div>
      <div className='links divcenternavbar'>
        <ul className='LinksLinks'>
          <a href='#'><li className='Exp'>Explore</li></a>
          <a href='#'><li className='Exp'>Solutions</li></a>
          <a href='#'><li className='Exp'>Articles</li></a>
          <a href='#'><li className='Exp'>Sign-in</li></a>
          <li ><button className='Join'>Join Now</button></li>
        </ul>
      </div>
  </div>
  )
}

export default Navbar