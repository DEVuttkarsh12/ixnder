import React from 'react'
import './Latest.css'
import Logo1 from './logo1.jpg'
import Logo2 from './logo2.jpg'


const Latest = () => {
  return (


<div className='MainLatestContainer'>
  <a href='#' className='viewview'>Discover All MasterPieces</a>
<div className='jlk'>

<h1 className='jjk'>Latest Masterpiece</h1>
</div>
<div className='MainLatestLatest'>
<div className='cardcard'>
  <button className='Promoted'>Promoted</button>
<div className='ccc'>
  <img src={Logo1} className='iki'/>
  <h5 className='Flowertext'>Flower Decorations<br/>
    by malvina spring
  </h5>
  <br/>
  {/* <h6></h6> */}
</div>
</div>
<div className='cardcard2'>
<button className='Promoted1'>Featured</button>
<div className='ccc1'>

<img src={Logo2} className='iki'/>
  <h5 className='Flowertext'>Flower Decorations<br/>
    by malvina spring
  </h5>
  <br/>
</div>
</div>
<div className='cardcard3'>
<div className='ccc2'>
<img src={Logo1} className='iki'/>
  <h5 className='Flowertext'>Splash<br/>
    by Rawanda Melflor
  </h5>
  <br/>
</div>
</div>
<div className='cardcard4'>
<div className='ccc3'>
<img src={Logo2} className='iki'/>
  <h5 className='Flowertext'>Colourfull Face<br/>
    by malvina spring
  </h5>
  <br/>
</div>
</div>
</div>

    </div>
  )
}

export default Latest