import React from 'react'
import './BeIncredible.css'


const BeIncredible = () => {
  return (
    <div className='IncredibleContainer'>
        <div className='incre'>
            <h1 className='tol'>Be Incredible</h1>
            <h4 className='fgfg'>
                Hello world how are you and also<br></br> 
                what are you doing by the way<br></br>
                my full name is uttkarsh<br></br> 
                bhardwaj
            </h4>
            <button className='bbsb1'>Explore Xinder</button>
        </div>
    </div>
  )
}

export default BeIncredible