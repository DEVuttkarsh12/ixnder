import React from 'react'
import './Solutions.css'
import { MdDone } from "react-icons/md";
import Image1 from './img1.png'

const Solutions = () => {
  return (
    <div className='MainSolution'>
         <img src={Image1} className='imimimi' />
<div className='InnertextContainer'>
    <h1 className='mb'>Best Solutions for your<br />
         demanding
        collections
    </h1>
    <h5 className='bnb'>Hello world how are you and also what are you doing
        by the way<br />
         my full name is uttkarsh bhardwaj
    </h5>
    <ul className='ululul'>
        <li className='nolnol'><span className='aps'><MdDone />
        </span>Hello world how are you and also what are you doing</li>
        <li className='nolnol'><span className='aps'><MdDone />
        </span>Hello world how are you and also </li>
        <li className='nolnol'><span className='aps'><MdDone />
        </span>Hello world how are you </li>
    </ul>
 
    <button className='bbsb'>Explore Xinder</button>
    
</div>
    </div>
  )
}

export default Solutions