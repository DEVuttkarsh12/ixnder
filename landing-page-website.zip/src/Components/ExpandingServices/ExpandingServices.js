import React from 'react'
import './ExpandingServices.css'
import { FaHome } from "react-icons/fa";
import Icon1 from './icon.png'

const ExpandingServices = () => {
  return (
    <div className='ExpandingServices'>
        <h1 className='plp'>Expanding Services</h1>
        <div className='icons'>
            <div className='innericon' >
            <FaHome size={65} color='red' className='imim'/>
                {/* <img src={Icon1} className='imim' /> */}
                <h5 className='hhhooo'>Nibh Viverra</h5>
            </div>
            {/* <div className='innericon' >
                <img src={Icon1} className='imim' />
                <h5 className='hhhooo'>Nibh Viverra</h5>
            </div> */}
            <div className='innericon' >
            <FaHome size={65} color='red' className='imim'/>
                {/* <img src={Icon1} className='imim' /> */}
                <h5 className='hhhooo'>Nibh Viverra</h5>
            </div>
            <div className='innericon' >
            <FaHome size={65} color='red' className='imim'/>
                {/* <img src={Icon1} className='imim' /> */}
                <h5 className='hhhooo'>Nibh Viverra</h5>
            </div>
            <div className='innericon' >
            <FaHome size={65} color='red' className='imim'/>
                {/* <img src={Icon1} className='imim' /> */}
                <h5 className='hhhooo'>Nibh Viverra</h5>
            </div>
            <div className='innericon' >
            <FaHome size={65} color='red' className='imim'/>
                {/* <img src={Icon1} className='imim' /> */}
                <h5 className='hhhooo'>Nibh Viverra</h5>
            </div>
        </div>
        <button className='bbk'>Find Services</button>
    </div>
  )
}

export default ExpandingServices